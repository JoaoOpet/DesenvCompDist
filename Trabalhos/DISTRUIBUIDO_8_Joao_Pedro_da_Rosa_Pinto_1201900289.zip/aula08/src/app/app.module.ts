import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {AngularFireModule} from '@angular/fire';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    AngularFireModule.initializeApp({
      apiKey: "AIzaSyDKf5AGt5obQrAudXZxXCjxouKOnGQH6MA",
      authDomain: "aula08-f8bd0.firebaseapp.com",
      projectId: "aula08-f8bd0",
      storageBucket: "aula08-f8bd0.appspot.com",
      messagingSenderId: "741454168427",
      appId: '1:741454168427:web:cee13a26faf973b94c8c2e'
    }),
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
